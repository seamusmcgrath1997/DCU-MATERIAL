#!/usr/bin/env python

import functions

def calc_dic_retrieve(dic, key):
  if key in dic:
    s = dic[key]
    return [key, s]
  else:
    return [key, "0"]

def general_calc(dic, calc_dic):
  #Annual salary (before pension contributions)
  li = calc_dic_retrieve(dic, "gae")[1]
  dic["gae"] = round(dic["gae"], 2)
  calc_dic = functions.add_diction(calc_dic, ["before_pen", li])

  #Annual salary (after pension contributions)
  li = calc_dic_retrieve(dic, "epc")
  li[1] = round(int(calc_dic["before_pen"]) - int(li[1]), 2)
  li[0] = "after_pen"
  functions.add_diction(calc_dic, li)

  #Gross income
  calc_dic["gross_income"] = round(int(calc_dic["after_pen"]) + int(dic["se"]) + int(dic["swp"]) + int(dic["in"]), 2)

  #Tax payable
  def income_tax_calc(lcap, lcaptax):
    if int(calc_dic["gross_income"]) <= lcap:
      calc_dic["income_tax"] = round(int(calc_dic["gross_income"]) / 100 * 20, 2)
      calc_dic["low_total_value"] = round(int(calc_dic["gross_income"]), 2)
      calc_dic["low_value_tax"] = round(int(calc_dic["gross_income"]) / 100 * 20, 2)
      calc_dic["high_total_value"] = round(0, 2)
      calc_dic["high_value_tax"] = round(0, 2)
    else:
      calc_dic["income_tax"] = round((int(calc_dic["gross_income"]) - lcap) / 100 * 40 + lcaptax, 2)
      calc_dic["low_total_value"] = round(lcap, 2)
      calc_dic["low_value_tax"] = round(lcaptax, 2)
      calc_dic["high_total_value"] = round((int(calc_dic["gross_income"]) - lcap), 2)
      calc_dic["high_value_tax"] = round((int(calc_dic["gross_income"]) - lcap) / 100 * 40, 2)

  if dic["marital"] == "single" or dic["marital"] == "widowed" and dic["child"] == "no":
    income_tax_calc(35300, 7060)
  elif dic["marital"] == "married":
    income_tax_calc(44300, 8860)
  elif dic["marital"] == "single" or dic["marital"] == "widowed" and dic["child"] == "yes":
    income_tax_calc(39300, 7860)

  #PRSI
  if dic["PRSI"] == "full":
    if int(calc_dic["gross_income"]) <= 18304:
      n = 0
    elif int(calc_dic["gross_income"]) > 18304 and int(calc_dic["gross_income"]) <=  22048:
      prsic = 12 - (int(calc_dic["gross_income"]) - 18304.52) / 6
      n = int(calc_dic["gross_income"]) * 0.04 - prsic
    elif int(calc_dic["gross_income"]) > 22048:
      n = int(calc_dic["gross_income"]) * 0.04
  elif dic["PRSI"] == "reduced":
    if int(calc_dic["gross_income"]) <= 18304:
      n = 0
    elif int(calc_dic["gross_income"]) > 18304 and int(calc_dic["gross_income"]) <=  26000:
      n = int(calc_dic["gross_income"]) * 0.009
    elif int(calc_dic["gross_income"]) > 26000:
      if int(calc_dic["gross_income"]) <=  75036:
        n = int(calc_dic["gross_income"]) * 0.009
      else:
        n =  675.324 + (int(calc_dic["gross_income"]) - 75036) * 0.04
  calc_dic["prsi"] = round(n, 2)

  #Universal social charge
  if int(calc_dic["gross_income"]) <= 13000:
    usc = 0
  elif int(calc_dic["gross_income"]) > 13000 and int(dic["se"]) <= 100000:
    if int(calc_dic["gross_income"]) <= 20484:
      usc = 60.06 + (int(calc_dic["gross_income"]) - 12012) * 0.02
    elif int(calc_dic["gross_income"]) > 20484 and int(calc_dic["gross_income"]) <= 70044:
      usc = 229.5 + (int(calc_dic["gross_income"]) - 20484) * 0.045
    elif int(calc_dic["gross_income"]) > 70044:
      usc = 2459.7 + (int(calc_dic["gross_income"]) - 70044) * 0.08
  elif int(dic["age"]) >= 70 and int(calc_dic["gross_income"]) <= 60000 and int(calc_dic["gross_income"]) > 13000:
    usc = 60.06 + (int(calc_dic["gross_income"]) - 12012) * 0.02
  elif int(calc_dic["gross_income"]) > 13000 and int(dic["se"]) > 100000:
    if int(calc_dic["gross_income"]) <= 20484:
      usc = 60.06 + (int(calc_dic["gross_income"]) - 12012) * 0.02
    elif int(calc_dic["gross_income"]) > 20484 and int(calc_dic["gross_income"]) <= 70044:
      usc = 229.5 + (int(calc_dic["gross_income"]) - 20484) * 0.045
    elif int(calc_dic["gross_income"]) > 70044 and int(calc_dic["gross_income"]) <= 100000:
      usc = 2459.7 + (int(calc_dic["gross_income"]) - 70044) * 0.08
    elif int(calc_dic["gross_income"]) > 100000:
      usc =  4856.18 + (int(calc_dic["gross_income"]) - 100000) * 0.11
  calc_dic["usc"] = round(int(usc), 2)

  #Net tax due
  calc_dic["liab"] = round(int(calc_dic["low_value_tax"]) + int(calc_dic["high_value_tax"]), 2)
  calc_dic["net_tax"] = round(int(calc_dic["liab"]) - int(calc_dic["tax_credit"]), 2)
  
  #Total Deductions
  calc_dic["total_ded"] = round(int(calc_dic["net_tax"]) + int(calc_dic["usc"]) + int(calc_dic["prsi"]), 2)

  #Net income
  calc_dic["annual_dispos"] = round(int(calc_dic["gross_income"]) - int(calc_dic["total_ded"]), 2)
  calc_dic["mon_dispos"] = round(int(calc_dic["annual_dispos"]) / 12, 2)
  calc_dic["week_dispos"] = round(int(calc_dic["annual_dispos"]) / 52, 2)
