#!/usr/bin/env python

#  Read in the tax credit values
with open("../text_files/tax_credits.txt", "r") as f:
  li_cred = f.readlines()[1:]

# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#  Test if values from tax_credit.txt are integers
def string_error(s):
  t = "ok"
  try:
    s = int(s)
    return t
  except:
    t = "Error in the tax_credit.txt file. Please check and try again."

# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#  If there are a correct number of values in tax_credit.txt create a dictionary with the tax credit and their value
if len(li_cred) == 11:
  tax_credits = {}
  tax_names = ["single", "married", "paye", "widowed_child", "widowed", "single_child", "incapacitated", "blind", "age", "dependent", "carer"]
  i = 0
  while i < len(li_cred):
    s = li_cred[i].split(":")[-1]
    test = string_error(s)
    if test == "ok":
      tax_credits[str(tax_names[i])] = int(s)
    else:
      print test
    i += 1
# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#  If statements to add up tax credit values
def calc_value(info):
  tax_credit = 0
  if info["marital"] == "single":
    tax_credit += int(tax_credits["single"])
    if info["child"] == "yes":
      tax_credit += int(tax_credits["single_child"])

  if info["marital"] == "widowed":
    tax_credit += int(tax_credits["widowed"])
    if info["child"] == "yes":
      tax_credit += int(tax_credits["widowed_child"])

  if int(info["age"]) > 64:
    tax_credit += int(tax_credits["age"])

  if info["marital"] == "married":
    tax_credit += int(tax_credits["married"])

  if info["gae"] == "yes" or info["se"] == "yes" or info["swp"] == "yes" or info["in"] == "yes":
    tax_credit += int(tax_credits["paye"])

  if info["carer"] == "yes":
    tax_credit += int(tax_credits["carer"])

  if info["blind"] == "yes":
    tax_credit += int(tax_credits["blind"])

  if info["incapacitated"] == "yes":
    tax_credit += int(tax_credits["incapacitated"])

  if info["dependent"] == "yes":
    tax_credit += int(tax_credits["dependent"])

  return tax_credit
# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
