#!/usr/bin/env python

def append_li(li_main, li_given):
  i = 0
  while i < len(li_given):
    li_main.append(li_given[i])
    i += 1

def output(calc_info):
  li_main = ['  <!DOCTYPE html>\n', '  <html>\n', '  <head>\n', '  <link rel=\"stylesheet\" type=\"text/css\" href=\"StyleSheet.css\">\n', '  </head>\n', '  <body>\n', '  <h1>Your 2020 Income Tax will be</h1>\n', '  <table>\n', '    <tr class = table1>\n', '      <th><b>Tax Breakdown</b></th>\n', '      <th>2020</th>\n', '    </tr>\n', '    <tr>\n', '      <td>Annual Salary (<b>before</b> pension contributions)</td>\n']

  li_main.append("    <td>" + str(calc_info['before_pen']) + "</td>\n")

  append_li(li_main,['  </tr>\n', '  <tr>\n', '    <td>Annual Salary (<b>after</b> pension contributions)</td>\n'])

  li_main.append("    <td>" + str(calc_info['after_pen']) + "</td>\n")

  append_li(li_main,['  </tr>\n', '  <tr class = \"table1\">\n', '    <td><b>Gross Income</b></td>\n'])

  li_main.append("    <td>" + str(calc_info['gross_income']) + "</td>\n")

  append_li(li_main,['  </tr>\n', '  <tr class =\"table1\">\n', '    <td>Tax Payable</td>\n'])

  li_main.append("    <td>" + str(calc_info['low_total_value']) + "<br>@ 20%<br><br>" + str(calc_info['low_value_tax']) + "<br><br><br>" + str(calc_info['high_total_value']) +  "<br>@ 40%<br><br>" + str(calc_info['high_value_tax']) + '\n')

  append_li(li_main,['  </tr>\n', '  <tr>\n', '    <td>Total Tax Liability</td>\n'])

  li_main.append("    <td>" + str(calc_info['liab']) + "</td>\n")

  append_li(li_main,['  </tr>\n', '  <tr>\n', '    <td>Personal Tax Credits (less)</td>\n'])

  li_main.append("    <td>" + "-" + str(calc_info['tax_credit']) + "</td>\n")

  append_li(li_main,['  </tr>\n', '  <tr>\n', '    <td>Net Tax Due</td>\n'])

  li_main.append("    <td>" + str(calc_info['net_tax']) + "</td>\n")

  append_li(li_main,['  </tr>\n', '  <tr>\n', '    <td>PRSI</td>\n'])

  li_main.append("    <td>" + str(calc_info['prsi']) + "</td>\n")

  append_li(li_main,['  </tr>\n', '  <tr>\n', '    <td>Universal Social Charge</td>\n'])

  li_main.append("    <td>" + str(calc_info['usc']) + "</td>\n")

  append_li(li_main,['  </tr>\n', '  <tr class = table1>\n', '    <td><b>Total Deductions</b></td>\n'])

  li_main.append("    <td>" + str(calc_info['total_ded']) + "</td>\n")

  append_li(li_main,['  </tr>\n', '  <tr class = table1>\n', '    <td>Annual Disposable Income</td>\n'])

  li_main.append("    <td>" + str(calc_info['annual_dispos']) + "</td>\n" + "  </tr>\n")

  append_li(li_main,['  <tr class = table1>\n', '    <td>Monthy Disposable Income</td>\n'])

  li_main.append("    <td>" + str(calc_info['mon_dispos']) + "</td>\n")

  append_li(li_main,['  </tr>\n', '  <tr class = table1>\n', '    <td>Weekly Disposable Income</td>\n'])

  li_main.append("    <td>" + str(calc_info['week_dispos']) + "</td>\n")

  append_li(li_main,['  </tr>\n', '</table>\n', '</body>\n', '</html>\n'])

  with open("../website/index.html", "w") as f:
    i = 0
    while i < len(li_main):
      f.write(str(li_main[i]))
      i += 1
