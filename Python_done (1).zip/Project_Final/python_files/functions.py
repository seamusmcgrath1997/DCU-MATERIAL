#!/usr/bin/env python

# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

#  Function to add new key to a given dictionary
def add_diction(dic, li):
  dic[str(li[0])] = li[1]
  return dic

# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

#  Verify input functions
def whole_number():
  while True:
    n = raw_input("Amount: ")
    try:
      n = int(n)
      try:
        if n < 1:
          print "\nThere is an error, the number you entered is not greater than 0.\nPlease enter a whole positive number greater than 0.\n"
          continue
        else:
          return n
          break
      except:
        print "\nThere has been an incorrect value entered.\nPlease enter a whole positive number greater than 0.\n"
        continue
    except:
      print "\nThe value you entered is a string.\nPlease enter a whole positive number greater than 0.\n"
      continue

     
#  Split a string into a two segments and check the tax credit value can be converted to an integer
def split_string(s):
  msg = ""
  s_split = s.strip().lower().split(",")
  error1 = "\nThere is a split(\",\") error in the tax.txt file at the line: "
  error2 = "\nThere is a conversion to int() error in the tax.txt file. Please remove all whitespace and typos at the line: "
  if len(s_split) != 2:
    print error1 + "'" + str(s).strip() + "'." + "\nReturn Value: " + str(s_split)
    msg = "error"
  try:
    n = int(s_split[1])
  except:
    print error2 + "'" + str(s).strip() + "'." + "\nReturn Value: " + str(s_split)
    msg = "error"
  if msg == "error":
    return msg
  else:
    return s_split
# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

#  Function to ask a question and verify response
def check_and_add(question,li,s):  #  Take in the question, the list of accepted answers and the key for the dictionary
  error = "\nError, please try again\n"
  print question
  ans = raw_input("Response: ").lower().strip()
  i = 0
  while True:
    if ans == li[i]:
      break
    elif i == len(li) - 1 and ans != li[i]:  #  Error probably typo
      i = 0
      print error
      ans = raw_input("Response: ").lower().strip()
      continue
    i += 1
  return [s, ans]  #  Return the key and its answer in a list

# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

#  Function for if question is true then a value is requested
def check_and_request(question, key):
  error = "\nError, please try again\n"
  amount = 0
  print question + " (yes or no)"  #  Ask the first question
  ans = raw_input("Response: ").lower().strip()
  while True:
    if ans == "yes":  #  If "yes" go to "A"
      break
    elif ans == "no":  #  If "no" return key and value 0
      return [key, amount]
      break
    else:  #  Error probably typo
      print error
      ans = raw_input("Response: ").lower().strip()
      continue
  if ans == "yes":
    print "\nPlease enter the amount."  #  Request the amount
    amount = whole_number()
    return [key, amount]
# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#  

