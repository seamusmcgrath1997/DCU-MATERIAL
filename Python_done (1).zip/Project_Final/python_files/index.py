#!/usr/bin/env python

#  This file contain the main actions of the this project, all functions are used here but are stored in the 'functions.py' file, imported below.
import functions
# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#  Error Message
error = "\nError, please try again\n"
# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#  Starting value of tax credits prior to initiation
info = {}

#  Request Martial Status Credits
li = (functions.check_and_add("Please enter your marital status (single, married or widowed)",["single", "married", "widowed"], "marital"))
functions.add_diction(info, li)

#  Request Number of Dependent Children if single or married
if info["marital"] != "married":
  li = functions.check_and_add("\nDo you have any dependent children of which you are the principal carer? (yes or no)",  ["yes", "no"], "child")
  functions.add_diction(info, li)

#  Request Age
print "\nWhat age are you? (15 - 130)"
while True:
  age = raw_input("Age: ").strip()
  try:
    age = int(age)
    if age > 14 and age < 131:
      break
    else:
      print error
      continue
  except:
    print error
    continue
functions.add_diction(info, ["age", age])

#  Request PRSI Category
li = functions.check_and_add("\nWhat is your PRSI category? (full or reduced)", ["full", "reduced"], "PRSI")
functions.add_diction(info, li)
# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#  Types of income values [gae, epc, se, swp, in]

#  Request Gross Annual Employment Income(GAE)
li = functions.check_and_request("\nDo you have a gross annual employment income?", "gae")
functions.add_diction(info, li)

#  Request Employee Pension Contributions(epc)
if info["gae"] != 0:
  li = functions.check_and_request("\nDo you make employee pension contributions?", "epc")
  functions.add_diction(info, li)

#  Request Self-Employed Status(se)
li = functions.check_and_request("\nAre you self-employed?", "se")
functions.add_diction(info, li)

#  Request Social Welfare Pension(swp)
li = functions.check_and_request("\nDo you receive a social welfare pension?", "swp")
functions.add_diction(info, li)

#  Request Investments(in)
li = functions.check_and_request("\nDo you receive income from your investments?", "in")
functions.add_diction(info, li)
# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#  Extra Possible Tax Credits Available

print "Please answer yes to the tax credits applicable to you."

#  Check if Home Carer Tax Credit is applicable
li = functions.check_and_add("\nHome Carer? (yes or no)", ["yes", "no"], "carer")
functions.add_diction(info, li)

#  Check if Blind Tax Credit is applicable
li = functions.check_and_add("\nBlind? (yes or no)", ["yes", "no"], "blind")
functions.add_diction(info, li)

#  Check if Dependent Relative Tax Credit is applicable
li = functions.check_and_add("\nDependent Relative? (yes or no)", ["yes", "no"], "dependent")
functions.add_diction(info, li)

#  Check if Incapacitated Child Tax Credit is applicable
li = functions.check_and_add("\nIncapacitated Child? (yes or no)", ["yes", "no"], "incapacitated")
functions.add_diction(info, li)
# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#  Benefits In Kind

# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#  Tax Credits
import tax_credits
calc_info = {}
calc_info["tax_credit"] = int(tax_credits.calc_value(info))

# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#  Calculations
import calculations
calculations.general_calc(info, calc_info)

import output
output.output(calc_info)


import os.path

my_path = os.path.abspath(os.path.dirname(__file__))
path = os.path.join(my_path, "../website/index.html")

import webbrowser
webbrowser.open(path)
